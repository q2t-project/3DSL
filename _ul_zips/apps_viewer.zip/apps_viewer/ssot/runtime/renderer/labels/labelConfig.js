// viewer/runtime/renderer/labelConfig.js

// ラベル描画全般のチューニング用パラメータ
export const labelConfig = {
  // 3DSS の label.size=8 を「論理サイズ 1.0」の基準とみなす
  baseLabelSize: 8,

  // ワールド座標系での見た目
  world: {
    // size=8 のときの world 高さ
    baseHeight: 0.20,
    // 点の位置からどれだけ持ち上げるか（worldHeight に対する係数）
    offsetYFactor: 0.6,
  },

  // Canvas2D へのラスタライズ設定
  raster: {
    // 1 論理サイズあたり何 px で描くか
    supersamplePx: 64,
    // フォント px の下限／上限
    minFontPx: 8,
    maxFontPx: 256,
    // 文字周りの padding(px)
    padding: 4,
    // フォントファミリ
    fontFamily:
      'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  },

  // 文字色
  text: {
    fillStyle: "#ffffff",
  },

  // 背景矩形
  background: {
    enabled: false,
    fillStyle: "rgba(0, 0, 0, 0.65)",
  },

  // 文字アウトライン設定
  outline: {
    enabled: true,
    // Canvas 上の線幅(px) – supersample 高いので多少太めでOK
    widthPx: 4.,
    color: "rgba(0, 0, 0, 0.95)",
    lineJoin: "round",

    // アウトラインが切れないように追加の余白
    extraPaddingPx: 4,
  },
};
