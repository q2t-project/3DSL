#!/usr/bin/env node
// Deprecated: moved to packages/3dss-content/scripts/check-library.mjs
console.error('[deprecated] use: node packages/3dss-content/scripts/check-library.mjs');
process.exit(1);
