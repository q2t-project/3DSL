// viewerHostBoot.js
import { mountViewerHost } from "./viewerHost.js";

function showFatal(e) {
  try {
    const el = document.getElementById("fallback");
    if (!el) return;
    const msg = e && (e.stack || e.message) ? String(e.stack || e.message) : String(e);
    el.textContent = `[viewer] boot failed\n${msg}`;
  } catch (_err) {}
}

(async () => {
  // dev/HMR/手動再実行でも二重マウントせんように
  try { window.__vh?.dispose?.(); } catch (_e) {}
  window.__vh = null;

  const p = new URLSearchParams(location.search);

  // allow small boot toggles for debugging
  const mode = p.get("mode") || "prod"; // "prod" | "dev"

  // simple model selection
  const modelUrl = p.get("model") || "";

  // embed mode: hide UI chrome (viewer.css uses body.is-embed)
  if (p.get("embed") === "1") {
    try { document.body.classList.add("is-embed"); } catch (_e) {}
  }

  const host = await mountViewerHost({
    mode,
    modelUrl,
    qs: p,
  });

  window.__vh = host;
})().catch(showFatal);
