// viewer/ui/presetViews.js

// 3D gizmo 内でプリセットビューを扱うようにしたので、
// ここでは特に何もしない。
export function attachPresetViews(_hub) {
  // no-op
}
