# tools (fix15)

- `headers_fix15.json` は `3dss_xlsx_template_v3_fix15.xlsm` のヘッダ行（row1）と一致。
- 旧 `headers_fix9.json` は過去版互換として残している（fix15 では参照しない前提）。

用途:
- テンプレ生成や列比較のスクリプト側で「今どの列を使っているか」を固定できる。
