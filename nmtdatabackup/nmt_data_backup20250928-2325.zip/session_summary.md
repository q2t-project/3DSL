# セッション記録まとめ

## 1. 問題の発端
- `index.html` 実行時に **JSON Schema の外部参照（draft-2020-12）** が `404` となりエラーが発生。
- そのため **バリデーション処理が fallback に常に流れる**状態だった。

## 2. 対処の試行
- **counts 表示機能**を削除して UI をシンプル化。  
- `schemas/draft-2020-12-schema.json` をリポジトリに配置し、fetch で読み込むよう修正。  
- しかし依然として Ajv の import 部分でエラーが発生。  

## 3. Ajv の取り扱い
- `import Ajv from "ajv";` などの方法では **ESM/UMD ビルドの差異**により失敗。  
- CDN を `<script src>` で直読みする方法も試したが、モジュールと競合して失敗。  
- import map + `https://esm.sh/ajv@8/dist/2020` を指定して、**Ajv 本体は正常 import できる状態**を確認。
- ただし `ajv.version` プロパティは ESM 版には無く、`undefined`。  
  → **バリデーションは正常に動作している**（テスト schema で `true/false` 判定を確認）。

## 4. 今後の進め方（方針）
- `ajv.version` の確認は不要。  
- `loadSchemas()` 内で：
  1. Ajv インスタンス生成  
  2. ローカルの `draft-2020-12-schema.json` を `ajv.addSchema()` で登録  
  3. `digidiorama.schema.json` と `manifest.schema.json` を fetch & compile  
- これで schema バリデーションが **外部参照に依存せずローカル完結**する。

## 現状の確認済みポイント
- Ajv は import 可能であり、バリデーション機能は利用可能。  
- `schema load failed` のエラーは **外部参照に引っ張られているだけ**。  
- ローカルスキーマを適切に読み込ませれば解決できる見通し。

## キーワード
**counts 削除 / Ajv import map / ajv.version undefined / fallback 最小 schema / ローカル draft-2020-12-schema.json**
