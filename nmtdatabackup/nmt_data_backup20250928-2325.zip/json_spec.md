# Digidiorama JSON Specification (v2)

## 1. ルート構造
```json
{
  "meta": { ... },
  "nodes": [ ... ],
  "edges": [ ... ],
  "auxiliary": [ ... ]
}
2. meta
title: モデル名

version: "v2"

date: ISO8601

counts: Viewer 側で計算して表示（Nodes/Edges数）

3. nodes
id: 一意識別子

label: 表示文字列

labelAttr (任意)

plane: xy | yz | zx （デフォルト: zx）

background: 背景色（デフォルト: 無し → アウトラインで代替）

direction: 将来拡張（角度指定、単位は未確定）

pos: [x, y, z]

4. edges
source: ノードID

target: ノードID

label: 任意

5. auxiliary
グリッド、軸、注釈など追加表示用の要素群

表示ON/OFFはViewerのLayersで制御

6. バージョン管理
JSONファイルには version: "v2" を必須とする

Viewer 側で v1 → v2 変換は未実装（今後拡張）

7. 今後の拡張候補
labelAttr.direction の仕様明確化（deg / rad）

ラベル表示方式（カメラ固定 vs 平面固定）の切替

JSONスキーマに v1/v2 マイグレーション定義