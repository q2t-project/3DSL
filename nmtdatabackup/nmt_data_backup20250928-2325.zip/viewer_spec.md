# Digidiorama Viewer Specification (v2)

## 1. 基本構成
- 単一HTML (`index.html`) による構成
- Three.js (ESM + Import Maps)
- OrbitControls による操作
- 左パネル：ファイルロード・メタ情報
- 右パネル：レイヤー・コントロール
- 中央：3Dビュー

---

## 2. UI 要素

### 上部
- **ファイルロード**
  - JSONファイルをローカル/URLから読み込み
  - ローダーは HTTP ステータス検査と JSON.parse ガードを実装
- **Reset ボタン**
  - 完全リセット（カメラ位置、クリッピング、選択状態を初期化）
- **Fit ボタン**
  - シーン全体にカメラを調整（状態は保持）

### 左パネル（Meta）
- JSON メタ情報表示
- **counts 表示**: ノード数・エッジ数
- バージョン表記：`schema v2 • YYYY-MM-DD`

### 右パネル（Layers）
- 表示レイヤー切替
- 状態は localStorage に保存
  - キー：`ddv:v2:layers`
  - 初回ロード時に旧 `"layers"` をマージ

---

## 3. ラベル表示
- **labelAttr.plane**
  - 指定平面に固定: `xy | yz | zx`
  - デフォルト: `zx`
- **labelAttr.background**
  - デフォルト: 無し（null）
  - 未指定時は背景を描画せず、アウトライン (2px, 黒系) を付与

---

## 4. favicon
- 404対策としてインラインSVGを埋め込み済み

---

## 5. バージョン管理
- `schema v2` に準拠
- JSONローダーと Viewer の互換性は v2ベース

---

## 6. 今後の拡張候補
- ラベル視認性オプション（シャドウ、太縁）
- `labelAttr.direction` の角度単位の明示
- レイヤー状態のURL共有
- カメラ状態のURL共有
- JSON v1 → v2 自動マイグレーション
